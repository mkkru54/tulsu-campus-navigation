window.BUILDING = {
  "name": "ТулГУ · корпус №9",
  "address": "Тула, проспект Ленина, 92",
  "surveyDate": "2026-10-03",
  "geometryStatus": "demonstration-only",
  "weightUnit": "условная стоимость",
  "floors": [
    1,
    2,
    3,
    4,
    5,
    6,
    7,
    8
  ],
  "nodes": [
    {
      "id": "c1-0",
      "label": "Коридор",
      "floor": 1,
      "x": 140,
      "y": 250,
      "kind": "corridor",
      "positionStatus": "needs-survey"
    },
    {
      "id": "c1-1",
      "label": "Коридор",
      "floor": 1,
      "x": 195,
      "y": 250,
      "kind": "corridor",
      "positionStatus": "needs-survey"
    },
    {
      "id": "c1-2",
      "label": "Коридор",
      "floor": 1,
      "x": 250,
      "y": 250,
      "kind": "corridor",
      "positionStatus": "needs-survey"
    },
    {
      "id": "c1-3",
      "label": "Коридор",
      "floor": 1,
      "x": 305,
      "y": 250,
      "kind": "corridor",
      "positionStatus": "needs-survey"
    },
    {
      "id": "c1-4",
      "label": "Коридор",
      "floor": 1,
      "x": 360,
      "y": 250,
      "kind": "corridor",
      "positionStatus": "needs-survey"
    },
    {
      "id": "c1-5",
      "label": "Коридор",
      "floor": 1,
      "x": 415,
      "y": 250,
      "kind": "corridor",
      "positionStatus": "needs-survey"
    },
    {
      "id": "c1-6",
      "label": "Коридор",
      "floor": 1,
      "x": 470,
      "y": 250,
      "kind": "corridor",
      "positionStatus": "needs-survey"
    },
    {
      "id": "c1-7",
      "label": "Коридор",
      "floor": 1,
      "x": 525,
      "y": 250,
      "kind": "corridor",
      "positionStatus": "needs-survey"
    },
    {
      "id": "c1-8",
      "label": "Коридор",
      "floor": 1,
      "x": 580,
      "y": 250,
      "kind": "corridor",
      "positionStatus": "needs-survey"
    },
    {
      "id": "c1-9",
      "label": "Коридор",
      "floor": 1,
      "x": 635,
      "y": 250,
      "kind": "corridor",
      "positionStatus": "needs-survey"
    },
    {
      "id": "c1-10",
      "label": "Коридор",
      "floor": 1,
      "x": 690,
      "y": 250,
      "kind": "corridor",
      "positionStatus": "needs-survey"
    },
    {
      "id": "c1-11",
      "label": "Коридор",
      "floor": 1,
      "x": 745,
      "y": 250,
      "kind": "corridor",
      "positionStatus": "needs-survey"
    },
    {
      "id": "c1-12",
      "label": "Коридор",
      "floor": 1,
      "x": 800,
      "y": 250,
      "kind": "corridor",
      "positionStatus": "needs-survey"
    },
    {
      "id": "c1-13",
      "label": "Коридор",
      "floor": 1,
      "x": 855,
      "y": 250,
      "kind": "corridor",
      "positionStatus": "needs-survey"
    },
    {
      "id": "c1-14",
      "label": "Коридор",
      "floor": 1,
      "x": 910,
      "y": 250,
      "kind": "corridor",
      "positionStatus": "needs-survey"
    },
    {
      "id": "c1-15",
      "label": "Коридор",
      "floor": 1,
      "x": 965,
      "y": 250,
      "kind": "corridor",
      "positionStatus": "needs-survey"
    },
    {
      "id": "c1-16",
      "label": "Коридор",
      "floor": 1,
      "x": 1020,
      "y": 250,
      "kind": "corridor",
      "positionStatus": "needs-survey"
    },
    {
      "id": "c1-17",
      "label": "Коридор",
      "floor": 1,
      "x": 1075,
      "y": 250,
      "kind": "corridor",
      "positionStatus": "needs-survey"
    },
    {
      "id": "c1-18",
      "label": "Коридор",
      "floor": 1,
      "x": 1130,
      "y": 250,
      "kind": "corridor",
      "positionStatus": "needs-survey"
    },
    {
      "id": "101",
      "label": "Аудитория 101",
      "floor": 1,
      "x": 140,
      "y": 170,
      "kind": "room",
      "existenceStatus": "official-list",
      "floorStatus": "inferred-from-number",
      "positionStatus": "needs-survey",
      "source": "cabs"
    },
    {
      "id": "113",
      "label": "Аудитория 113",
      "floor": 1,
      "x": 195,
      "y": 330,
      "kind": "room",
      "existenceStatus": "official-list",
      "floorStatus": "inferred-from-number",
      "positionStatus": "needs-survey",
      "source": "cabs"
    },
    {
      "id": "122",
      "label": "Аудитория 122",
      "floor": 1,
      "x": 250,
      "y": 170,
      "kind": "room",
      "existenceStatus": "official-list",
      "floorStatus": "inferred-from-number",
      "positionStatus": "needs-survey",
      "source": "cabs"
    },
    {
      "id": "124",
      "label": "Аудитория 124",
      "floor": 1,
      "x": 305,
      "y": 330,
      "kind": "room",
      "existenceStatus": "official-list",
      "floorStatus": "inferred-from-number",
      "positionStatus": "needs-survey",
      "source": "cabs"
    },
    {
      "id": "sA1",
      "label": "Лестница A",
      "floor": 1,
      "x": 140,
      "y": 250,
      "kind": "stairs",
      "positionStatus": "needs-survey"
    },
    {
      "id": "sB1",
      "label": "Лестница B",
      "floor": 1,
      "x": 1130,
      "y": 250,
      "kind": "stairs",
      "positionStatus": "needs-survey"
    },
    {
      "id": "c2-0",
      "label": "Коридор",
      "floor": 2,
      "x": 140,
      "y": 250,
      "kind": "corridor",
      "positionStatus": "needs-survey"
    },
    {
      "id": "c2-1",
      "label": "Коридор",
      "floor": 2,
      "x": 195,
      "y": 250,
      "kind": "corridor",
      "positionStatus": "needs-survey"
    },
    {
      "id": "c2-2",
      "label": "Коридор",
      "floor": 2,
      "x": 250,
      "y": 250,
      "kind": "corridor",
      "positionStatus": "needs-survey"
    },
    {
      "id": "c2-3",
      "label": "Коридор",
      "floor": 2,
      "x": 305,
      "y": 250,
      "kind": "corridor",
      "positionStatus": "needs-survey"
    },
    {
      "id": "c2-4",
      "label": "Коридор",
      "floor": 2,
      "x": 360,
      "y": 250,
      "kind": "corridor",
      "positionStatus": "needs-survey"
    },
    {
      "id": "c2-5",
      "label": "Коридор",
      "floor": 2,
      "x": 415,
      "y": 250,
      "kind": "corridor",
      "positionStatus": "needs-survey"
    },
    {
      "id": "c2-6",
      "label": "Коридор",
      "floor": 2,
      "x": 470,
      "y": 250,
      "kind": "corridor",
      "positionStatus": "needs-survey"
    },
    {
      "id": "c2-7",
      "label": "Коридор",
      "floor": 2,
      "x": 525,
      "y": 250,
      "kind": "corridor",
      "positionStatus": "needs-survey"
    },
    {
      "id": "c2-8",
      "label": "Коридор",
      "floor": 2,
      "x": 580,
      "y": 250,
      "kind": "corridor",
      "positionStatus": "needs-survey"
    },
    {
      "id": "c2-9",
      "label": "Коридор",
      "floor": 2,
      "x": 635,
      "y": 250,
      "kind": "corridor",
      "positionStatus": "needs-survey"
    },
    {
      "id": "c2-10",
      "label": "Коридор",
      "floor": 2,
      "x": 690,
      "y": 250,
      "kind": "corridor",
      "positionStatus": "needs-survey"
    },
    {
      "id": "c2-11",
      "label": "Коридор",
      "floor": 2,
      "x": 745,
      "y": 250,
      "kind": "corridor",
      "positionStatus": "needs-survey"
    },
    {
      "id": "c2-12",
      "label": "Коридор",
      "floor": 2,
      "x": 800,
      "y": 250,
      "kind": "corridor",
      "positionStatus": "needs-survey"
    },
    {
      "id": "c2-13",
      "label": "Коридор",
      "floor": 2,
      "x": 855,
      "y": 250,
      "kind": "corridor",
      "positionStatus": "needs-survey"
    },
    {
      "id": "c2-14",
      "label": "Коридор",
      "floor": 2,
      "x": 910,
      "y": 250,
      "kind": "corridor",
      "positionStatus": "needs-survey"
    },
    {
      "id": "c2-15",
      "label": "Коридор",
      "floor": 2,
      "x": 965,
      "y": 250,
      "kind": "corridor",
      "positionStatus": "needs-survey"
    },
    {
      "id": "c2-16",
      "label": "Коридор",
      "floor": 2,
      "x": 1020,
      "y": 250,
      "kind": "corridor",
      "positionStatus": "needs-survey"
    },
    {
      "id": "c2-17",
      "label": "Коридор",
      "floor": 2,
      "x": 1075,
      "y": 250,
      "kind": "corridor",
      "positionStatus": "needs-survey"
    },
    {
      "id": "c2-18",
      "label": "Коридор",
      "floor": 2,
      "x": 1130,
      "y": 250,
      "kind": "corridor",
      "positionStatus": "needs-survey"
    },
    {
      "id": "201",
      "label": "Аудитория 201",
      "floor": 2,
      "x": 140,
      "y": 170,
      "kind": "room",
      "existenceStatus": "official-list",
      "floorStatus": "inferred-from-number",
      "positionStatus": "needs-survey",
      "source": "cabs"
    },
    {
      "id": "202",
      "label": "Аудитория 202",
      "floor": 2,
      "x": 195,
      "y": 330,
      "kind": "room",
      "existenceStatus": "official-list",
      "floorStatus": "inferred-from-number",
      "positionStatus": "needs-survey",
      "source": "cabs"
    },
    {
      "id": "203",
      "label": "Аудитория 203",
      "floor": 2,
      "x": 250,
      "y": 170,
      "kind": "room",
      "existenceStatus": "official-list",
      "floorStatus": "inferred-from-number",
      "positionStatus": "needs-survey",
      "source": "cabs"
    },
    {
      "id": "204",
      "label": "Аудитория 204",
      "floor": 2,
      "x": 305,
      "y": 330,
      "kind": "room",
      "existenceStatus": "official-list",
      "floorStatus": "inferred-from-number",
      "positionStatus": "needs-survey",
      "source": "cabs"
    },
    {
      "id": "205",
      "label": "Аудитория 205",
      "floor": 2,
      "x": 360,
      "y": 170,
      "kind": "room",
      "existenceStatus": "official-list",
      "floorStatus": "inferred-from-number",
      "positionStatus": "needs-survey",
      "source": "cabs"
    },
    {
      "id": "206",
      "label": "Аудитория 206",
      "floor": 2,
      "x": 415,
      "y": 330,
      "kind": "room",
      "existenceStatus": "official-list",
      "floorStatus": "inferred-from-number",
      "positionStatus": "needs-survey",
      "source": "cabs"
    },
    {
      "id": "207а",
      "label": "Аудитория 207а",
      "floor": 2,
      "x": 470,
      "y": 170,
      "kind": "room",
      "existenceStatus": "official-list",
      "floorStatus": "inferred-from-number",
      "positionStatus": "needs-survey",
      "source": "cabs"
    },
    {
      "id": "208",
      "label": "Аудитория 208",
      "floor": 2,
      "x": 525,
      "y": 330,
      "kind": "room",
      "existenceStatus": "official-list",
      "floorStatus": "inferred-from-number",
      "positionStatus": "needs-survey",
      "source": "cabs"
    },
    {
      "id": "210",
      "label": "Аудитория 210",
      "floor": 2,
      "x": 580,
      "y": 170,
      "kind": "room",
      "existenceStatus": "official-list",
      "floorStatus": "inferred-from-number",
      "positionStatus": "needs-survey",
      "source": "cabs"
    },
    {
      "id": "211",
      "label": "Аудитория 211",
      "floor": 2,
      "x": 635,
      "y": 330,
      "kind": "room",
      "existenceStatus": "official-list",
      "floorStatus": "inferred-from-number",
      "positionStatus": "needs-survey",
      "source": "cabs"
    },
    {
      "id": "212",
      "label": "Аудитория 212",
      "floor": 2,
      "x": 690,
      "y": 170,
      "kind": "room",
      "existenceStatus": "official-list",
      "floorStatus": "inferred-from-number",
      "positionStatus": "needs-survey",
      "source": "cabs"
    },
    {
      "id": "214",
      "label": "Аудитория 214",
      "floor": 2,
      "x": 745,
      "y": 330,
      "kind": "room",
      "existenceStatus": "official-list",
      "floorStatus": "inferred-from-number",
      "positionStatus": "needs-survey",
      "source": "cabs"
    },
    {
      "id": "216",
      "label": "Аудитория 216",
      "floor": 2,
      "x": 800,
      "y": 170,
      "kind": "room",
      "existenceStatus": "official-list",
      "floorStatus": "inferred-from-number",
      "positionStatus": "needs-survey",
      "source": "cabs"
    },
    {
      "id": "218",
      "label": "Аудитория 218",
      "floor": 2,
      "x": 855,
      "y": 330,
      "kind": "room",
      "existenceStatus": "official-list",
      "floorStatus": "inferred-from-number",
      "positionStatus": "needs-survey",
      "source": "cabs"
    },
    {
      "id": "220",
      "label": "Аудитория 220",
      "floor": 2,
      "x": 910,
      "y": 170,
      "kind": "room",
      "existenceStatus": "official-list",
      "floorStatus": "inferred-from-number",
      "positionStatus": "needs-survey",
      "source": "cabs"
    },
    {
      "id": "224",
      "label": "Аудитория 224",
      "floor": 2,
      "x": 965,
      "y": 330,
      "kind": "room",
      "existenceStatus": "official-list",
      "floorStatus": "inferred-from-number",
      "positionStatus": "needs-survey",
      "source": "cabs"
    },
    {
      "id": "226а",
      "label": "Аудитория 226а",
      "floor": 2,
      "x": 1020,
      "y": 170,
      "kind": "room",
      "existenceStatus": "official-list",
      "floorStatus": "inferred-from-number",
      "positionStatus": "needs-survey",
      "source": "cabs"
    },
    {
      "id": "226б",
      "label": "Аудитория 226б",
      "floor": 2,
      "x": 1075,
      "y": 330,
      "kind": "room",
      "existenceStatus": "official-list",
      "floorStatus": "inferred-from-number",
      "positionStatus": "needs-survey",
      "source": "cabs"
    },
    {
      "id": "226в",
      "label": "Аудитория 226в",
      "floor": 2,
      "x": 1130,
      "y": 170,
      "kind": "room",
      "existenceStatus": "official-list",
      "floorStatus": "inferred-from-number",
      "positionStatus": "needs-survey",
      "source": "cabs"
    },
    {
      "id": "sA2",
      "label": "Лестница A",
      "floor": 2,
      "x": 140,
      "y": 250,
      "kind": "stairs",
      "positionStatus": "needs-survey"
    },
    {
      "id": "sB2",
      "label": "Лестница B",
      "floor": 2,
      "x": 1130,
      "y": 250,
      "kind": "stairs",
      "positionStatus": "needs-survey"
    },
    {
      "id": "c3-0",
      "label": "Коридор",
      "floor": 3,
      "x": 140,
      "y": 250,
      "kind": "corridor",
      "positionStatus": "needs-survey"
    },
    {
      "id": "c3-1",
      "label": "Коридор",
      "floor": 3,
      "x": 195,
      "y": 250,
      "kind": "corridor",
      "positionStatus": "needs-survey"
    },
    {
      "id": "c3-2",
      "label": "Коридор",
      "floor": 3,
      "x": 250,
      "y": 250,
      "kind": "corridor",
      "positionStatus": "needs-survey"
    },
    {
      "id": "c3-3",
      "label": "Коридор",
      "floor": 3,
      "x": 305,
      "y": 250,
      "kind": "corridor",
      "positionStatus": "needs-survey"
    },
    {
      "id": "c3-4",
      "label": "Коридор",
      "floor": 3,
      "x": 360,
      "y": 250,
      "kind": "corridor",
      "positionStatus": "needs-survey"
    },
    {
      "id": "c3-5",
      "label": "Коридор",
      "floor": 3,
      "x": 415,
      "y": 250,
      "kind": "corridor",
      "positionStatus": "needs-survey"
    },
    {
      "id": "c3-6",
      "label": "Коридор",
      "floor": 3,
      "x": 470,
      "y": 250,
      "kind": "corridor",
      "positionStatus": "needs-survey"
    },
    {
      "id": "c3-7",
      "label": "Коридор",
      "floor": 3,
      "x": 525,
      "y": 250,
      "kind": "corridor",
      "positionStatus": "needs-survey"
    },
    {
      "id": "c3-8",
      "label": "Коридор",
      "floor": 3,
      "x": 580,
      "y": 250,
      "kind": "corridor",
      "positionStatus": "needs-survey"
    },
    {
      "id": "c3-9",
      "label": "Коридор",
      "floor": 3,
      "x": 635,
      "y": 250,
      "kind": "corridor",
      "positionStatus": "needs-survey"
    },
    {
      "id": "c3-10",
      "label": "Коридор",
      "floor": 3,
      "x": 690,
      "y": 250,
      "kind": "corridor",
      "positionStatus": "needs-survey"
    },
    {
      "id": "c3-11",
      "label": "Коридор",
      "floor": 3,
      "x": 745,
      "y": 250,
      "kind": "corridor",
      "positionStatus": "needs-survey"
    },
    {
      "id": "c3-12",
      "label": "Коридор",
      "floor": 3,
      "x": 800,
      "y": 250,
      "kind": "corridor",
      "positionStatus": "needs-survey"
    },
    {
      "id": "c3-13",
      "label": "Коридор",
      "floor": 3,
      "x": 855,
      "y": 250,
      "kind": "corridor",
      "positionStatus": "needs-survey"
    },
    {
      "id": "c3-14",
      "label": "Коридор",
      "floor": 3,
      "x": 910,
      "y": 250,
      "kind": "corridor",
      "positionStatus": "needs-survey"
    },
    {
      "id": "c3-15",
      "label": "Коридор",
      "floor": 3,
      "x": 965,
      "y": 250,
      "kind": "corridor",
      "positionStatus": "needs-survey"
    },
    {
      "id": "c3-16",
      "label": "Коридор",
      "floor": 3,
      "x": 1020,
      "y": 250,
      "kind": "corridor",
      "positionStatus": "needs-survey"
    },
    {
      "id": "c3-17",
      "label": "Коридор",
      "floor": 3,
      "x": 1075,
      "y": 250,
      "kind": "corridor",
      "positionStatus": "needs-survey"
    },
    {
      "id": "c3-18",
      "label": "Коридор",
      "floor": 3,
      "x": 1130,
      "y": 250,
      "kind": "corridor",
      "positionStatus": "needs-survey"
    },
    {
      "id": "315",
      "label": "Аудитория 315",
      "floor": 3,
      "x": 140,
      "y": 170,
      "kind": "room",
      "existenceStatus": "official-list",
      "floorStatus": "inferred-from-number",
      "positionStatus": "needs-survey",
      "source": "cabs"
    },
    {
      "id": "sA3",
      "label": "Лестница A",
      "floor": 3,
      "x": 140,
      "y": 250,
      "kind": "stairs",
      "positionStatus": "needs-survey"
    },
    {
      "id": "sB3",
      "label": "Лестница B",
      "floor": 3,
      "x": 1130,
      "y": 250,
      "kind": "stairs",
      "positionStatus": "needs-survey"
    },
    {
      "id": "c4-0",
      "label": "Коридор",
      "floor": 4,
      "x": 140,
      "y": 250,
      "kind": "corridor",
      "positionStatus": "needs-survey"
    },
    {
      "id": "c4-1",
      "label": "Коридор",
      "floor": 4,
      "x": 195,
      "y": 250,
      "kind": "corridor",
      "positionStatus": "needs-survey"
    },
    {
      "id": "c4-2",
      "label": "Коридор",
      "floor": 4,
      "x": 250,
      "y": 250,
      "kind": "corridor",
      "positionStatus": "needs-survey"
    },
    {
      "id": "c4-3",
      "label": "Коридор",
      "floor": 4,
      "x": 305,
      "y": 250,
      "kind": "corridor",
      "positionStatus": "needs-survey"
    },
    {
      "id": "c4-4",
      "label": "Коридор",
      "floor": 4,
      "x": 360,
      "y": 250,
      "kind": "corridor",
      "positionStatus": "needs-survey"
    },
    {
      "id": "c4-5",
      "label": "Коридор",
      "floor": 4,
      "x": 415,
      "y": 250,
      "kind": "corridor",
      "positionStatus": "needs-survey"
    },
    {
      "id": "c4-6",
      "label": "Коридор",
      "floor": 4,
      "x": 470,
      "y": 250,
      "kind": "corridor",
      "positionStatus": "needs-survey"
    },
    {
      "id": "c4-7",
      "label": "Коридор",
      "floor": 4,
      "x": 525,
      "y": 250,
      "kind": "corridor",
      "positionStatus": "needs-survey"
    },
    {
      "id": "c4-8",
      "label": "Коридор",
      "floor": 4,
      "x": 580,
      "y": 250,
      "kind": "corridor",
      "positionStatus": "needs-survey"
    },
    {
      "id": "c4-9",
      "label": "Коридор",
      "floor": 4,
      "x": 635,
      "y": 250,
      "kind": "corridor",
      "positionStatus": "needs-survey"
    },
    {
      "id": "c4-10",
      "label": "Коридор",
      "floor": 4,
      "x": 690,
      "y": 250,
      "kind": "corridor",
      "positionStatus": "needs-survey"
    },
    {
      "id": "c4-11",
      "label": "Коридор",
      "floor": 4,
      "x": 745,
      "y": 250,
      "kind": "corridor",
      "positionStatus": "needs-survey"
    },
    {
      "id": "c4-12",
      "label": "Коридор",
      "floor": 4,
      "x": 800,
      "y": 250,
      "kind": "corridor",
      "positionStatus": "needs-survey"
    },
    {
      "id": "c4-13",
      "label": "Коридор",
      "floor": 4,
      "x": 855,
      "y": 250,
      "kind": "corridor",
      "positionStatus": "needs-survey"
    },
    {
      "id": "c4-14",
      "label": "Коридор",
      "floor": 4,
      "x": 910,
      "y": 250,
      "kind": "corridor",
      "positionStatus": "needs-survey"
    },
    {
      "id": "c4-15",
      "label": "Коридор",
      "floor": 4,
      "x": 965,
      "y": 250,
      "kind": "corridor",
      "positionStatus": "needs-survey"
    },
    {
      "id": "c4-16",
      "label": "Коридор",
      "floor": 4,
      "x": 1020,
      "y": 250,
      "kind": "corridor",
      "positionStatus": "needs-survey"
    },
    {
      "id": "c4-17",
      "label": "Коридор",
      "floor": 4,
      "x": 1075,
      "y": 250,
      "kind": "corridor",
      "positionStatus": "needs-survey"
    },
    {
      "id": "c4-18",
      "label": "Коридор",
      "floor": 4,
      "x": 1130,
      "y": 250,
      "kind": "corridor",
      "positionStatus": "needs-survey"
    },
    {
      "id": "402",
      "label": "Аудитория 402",
      "floor": 4,
      "x": 140,
      "y": 170,
      "kind": "room",
      "existenceStatus": "official-list",
      "floorStatus": "inferred-from-number",
      "positionStatus": "needs-survey",
      "source": "cabs"
    },
    {
      "id": "404",
      "label": "Аудитория 404",
      "floor": 4,
      "x": 195,
      "y": 330,
      "kind": "room",
      "existenceStatus": "official-list",
      "floorStatus": "inferred-from-number",
      "positionStatus": "needs-survey",
      "source": "cabs"
    },
    {
      "id": "405",
      "label": "Аудитория 405",
      "floor": 4,
      "x": 250,
      "y": 170,
      "kind": "room",
      "existenceStatus": "official-list",
      "floorStatus": "inferred-from-number",
      "positionStatus": "needs-survey",
      "source": "cabs"
    },
    {
      "id": "406",
      "label": "Аудитория 406",
      "floor": 4,
      "x": 305,
      "y": 330,
      "kind": "room",
      "existenceStatus": "official-list",
      "floorStatus": "inferred-from-number",
      "positionStatus": "needs-survey",
      "source": "cabs"
    },
    {
      "id": "407",
      "label": "Аудитория 407",
      "floor": 4,
      "x": 360,
      "y": 170,
      "kind": "room",
      "existenceStatus": "official-list",
      "floorStatus": "inferred-from-number",
      "positionStatus": "needs-survey",
      "source": "cabs"
    },
    {
      "id": "407а",
      "label": "Аудитория 407а",
      "floor": 4,
      "x": 415,
      "y": 330,
      "kind": "room",
      "existenceStatus": "official-list",
      "floorStatus": "inferred-from-number",
      "positionStatus": "needs-survey",
      "source": "cabs"
    },
    {
      "id": "412",
      "label": "Аудитория 412",
      "floor": 4,
      "x": 470,
      "y": 170,
      "kind": "room",
      "existenceStatus": "official-list",
      "floorStatus": "inferred-from-number",
      "positionStatus": "needs-survey",
      "source": "cabs"
    },
    {
      "id": "413а",
      "label": "Аудитория 413а",
      "floor": 4,
      "x": 525,
      "y": 330,
      "kind": "room",
      "existenceStatus": "official-list",
      "floorStatus": "inferred-from-number",
      "positionStatus": "needs-survey",
      "source": "cabs"
    },
    {
      "id": "418",
      "label": "Аудитория 418",
      "floor": 4,
      "x": 580,
      "y": 170,
      "kind": "room",
      "existenceStatus": "official-list",
      "floorStatus": "inferred-from-number",
      "positionStatus": "needs-survey",
      "source": "cabs"
    },
    {
      "id": "sA4",
      "label": "Лестница A",
      "floor": 4,
      "x": 140,
      "y": 250,
      "kind": "stairs",
      "positionStatus": "needs-survey"
    },
    {
      "id": "sB4",
      "label": "Лестница B",
      "floor": 4,
      "x": 1130,
      "y": 250,
      "kind": "stairs",
      "positionStatus": "needs-survey"
    },
    {
      "id": "c5-0",
      "label": "Коридор",
      "floor": 5,
      "x": 140,
      "y": 250,
      "kind": "corridor",
      "positionStatus": "needs-survey"
    },
    {
      "id": "c5-1",
      "label": "Коридор",
      "floor": 5,
      "x": 195,
      "y": 250,
      "kind": "corridor",
      "positionStatus": "needs-survey"
    },
    {
      "id": "c5-2",
      "label": "Коридор",
      "floor": 5,
      "x": 250,
      "y": 250,
      "kind": "corridor",
      "positionStatus": "needs-survey"
    },
    {
      "id": "c5-3",
      "label": "Коридор",
      "floor": 5,
      "x": 305,
      "y": 250,
      "kind": "corridor",
      "positionStatus": "needs-survey"
    },
    {
      "id": "c5-4",
      "label": "Коридор",
      "floor": 5,
      "x": 360,
      "y": 250,
      "kind": "corridor",
      "positionStatus": "needs-survey"
    },
    {
      "id": "c5-5",
      "label": "Коридор",
      "floor": 5,
      "x": 415,
      "y": 250,
      "kind": "corridor",
      "positionStatus": "needs-survey"
    },
    {
      "id": "c5-6",
      "label": "Коридор",
      "floor": 5,
      "x": 470,
      "y": 250,
      "kind": "corridor",
      "positionStatus": "needs-survey"
    },
    {
      "id": "c5-7",
      "label": "Коридор",
      "floor": 5,
      "x": 525,
      "y": 250,
      "kind": "corridor",
      "positionStatus": "needs-survey"
    },
    {
      "id": "c5-8",
      "label": "Коридор",
      "floor": 5,
      "x": 580,
      "y": 250,
      "kind": "corridor",
      "positionStatus": "needs-survey"
    },
    {
      "id": "c5-9",
      "label": "Коридор",
      "floor": 5,
      "x": 635,
      "y": 250,
      "kind": "corridor",
      "positionStatus": "needs-survey"
    },
    {
      "id": "c5-10",
      "label": "Коридор",
      "floor": 5,
      "x": 690,
      "y": 250,
      "kind": "corridor",
      "positionStatus": "needs-survey"
    },
    {
      "id": "c5-11",
      "label": "Коридор",
      "floor": 5,
      "x": 745,
      "y": 250,
      "kind": "corridor",
      "positionStatus": "needs-survey"
    },
    {
      "id": "c5-12",
      "label": "Коридор",
      "floor": 5,
      "x": 800,
      "y": 250,
      "kind": "corridor",
      "positionStatus": "needs-survey"
    },
    {
      "id": "c5-13",
      "label": "Коридор",
      "floor": 5,
      "x": 855,
      "y": 250,
      "kind": "corridor",
      "positionStatus": "needs-survey"
    },
    {
      "id": "c5-14",
      "label": "Коридор",
      "floor": 5,
      "x": 910,
      "y": 250,
      "kind": "corridor",
      "positionStatus": "needs-survey"
    },
    {
      "id": "c5-15",
      "label": "Коридор",
      "floor": 5,
      "x": 965,
      "y": 250,
      "kind": "corridor",
      "positionStatus": "needs-survey"
    },
    {
      "id": "c5-16",
      "label": "Коридор",
      "floor": 5,
      "x": 1020,
      "y": 250,
      "kind": "corridor",
      "positionStatus": "needs-survey"
    },
    {
      "id": "c5-17",
      "label": "Коридор",
      "floor": 5,
      "x": 1075,
      "y": 250,
      "kind": "corridor",
      "positionStatus": "needs-survey"
    },
    {
      "id": "c5-18",
      "label": "Коридор",
      "floor": 5,
      "x": 1130,
      "y": 250,
      "kind": "corridor",
      "positionStatus": "needs-survey"
    },
    {
      "id": "503",
      "label": "Аудитория 503",
      "floor": 5,
      "x": 140,
      "y": 170,
      "kind": "room",
      "existenceStatus": "official-list",
      "floorStatus": "inferred-from-number",
      "positionStatus": "needs-survey",
      "source": "cabs"
    },
    {
      "id": "511",
      "label": "Аудитория 511",
      "floor": 5,
      "x": 195,
      "y": 330,
      "kind": "room",
      "existenceStatus": "official-list",
      "floorStatus": "inferred-from-number",
      "positionStatus": "needs-survey",
      "source": "cabs"
    },
    {
      "id": "513",
      "label": "Аудитория 513",
      "floor": 5,
      "x": 250,
      "y": 170,
      "kind": "room",
      "existenceStatus": "official-list",
      "floorStatus": "inferred-from-number",
      "positionStatus": "needs-survey",
      "source": "cabs"
    },
    {
      "id": "515",
      "label": "Аудитория 515",
      "floor": 5,
      "x": 305,
      "y": 330,
      "kind": "room",
      "existenceStatus": "official-list",
      "floorStatus": "inferred-from-number",
      "positionStatus": "needs-survey",
      "source": "cabs"
    },
    {
      "id": "sA5",
      "label": "Лестница A",
      "floor": 5,
      "x": 140,
      "y": 250,
      "kind": "stairs",
      "positionStatus": "needs-survey"
    },
    {
      "id": "sB5",
      "label": "Лестница B",
      "floor": 5,
      "x": 1130,
      "y": 250,
      "kind": "stairs",
      "positionStatus": "needs-survey"
    },
    {
      "id": "c6-0",
      "label": "Коридор",
      "floor": 6,
      "x": 140,
      "y": 250,
      "kind": "corridor",
      "positionStatus": "needs-survey"
    },
    {
      "id": "c6-1",
      "label": "Коридор",
      "floor": 6,
      "x": 195,
      "y": 250,
      "kind": "corridor",
      "positionStatus": "needs-survey"
    },
    {
      "id": "c6-2",
      "label": "Коридор",
      "floor": 6,
      "x": 250,
      "y": 250,
      "kind": "corridor",
      "positionStatus": "needs-survey"
    },
    {
      "id": "c6-3",
      "label": "Коридор",
      "floor": 6,
      "x": 305,
      "y": 250,
      "kind": "corridor",
      "positionStatus": "needs-survey"
    },
    {
      "id": "c6-4",
      "label": "Коридор",
      "floor": 6,
      "x": 360,
      "y": 250,
      "kind": "corridor",
      "positionStatus": "needs-survey"
    },
    {
      "id": "c6-5",
      "label": "Коридор",
      "floor": 6,
      "x": 415,
      "y": 250,
      "kind": "corridor",
      "positionStatus": "needs-survey"
    },
    {
      "id": "c6-6",
      "label": "Коридор",
      "floor": 6,
      "x": 470,
      "y": 250,
      "kind": "corridor",
      "positionStatus": "needs-survey"
    },
    {
      "id": "c6-7",
      "label": "Коридор",
      "floor": 6,
      "x": 525,
      "y": 250,
      "kind": "corridor",
      "positionStatus": "needs-survey"
    },
    {
      "id": "c6-8",
      "label": "Коридор",
      "floor": 6,
      "x": 580,
      "y": 250,
      "kind": "corridor",
      "positionStatus": "needs-survey"
    },
    {
      "id": "c6-9",
      "label": "Коридор",
      "floor": 6,
      "x": 635,
      "y": 250,
      "kind": "corridor",
      "positionStatus": "needs-survey"
    },
    {
      "id": "c6-10",
      "label": "Коридор",
      "floor": 6,
      "x": 690,
      "y": 250,
      "kind": "corridor",
      "positionStatus": "needs-survey"
    },
    {
      "id": "c6-11",
      "label": "Коридор",
      "floor": 6,
      "x": 745,
      "y": 250,
      "kind": "corridor",
      "positionStatus": "needs-survey"
    },
    {
      "id": "c6-12",
      "label": "Коридор",
      "floor": 6,
      "x": 800,
      "y": 250,
      "kind": "corridor",
      "positionStatus": "needs-survey"
    },
    {
      "id": "c6-13",
      "label": "Коридор",
      "floor": 6,
      "x": 855,
      "y": 250,
      "kind": "corridor",
      "positionStatus": "needs-survey"
    },
    {
      "id": "c6-14",
      "label": "Коридор",
      "floor": 6,
      "x": 910,
      "y": 250,
      "kind": "corridor",
      "positionStatus": "needs-survey"
    },
    {
      "id": "c6-15",
      "label": "Коридор",
      "floor": 6,
      "x": 965,
      "y": 250,
      "kind": "corridor",
      "positionStatus": "needs-survey"
    },
    {
      "id": "c6-16",
      "label": "Коридор",
      "floor": 6,
      "x": 1020,
      "y": 250,
      "kind": "corridor",
      "positionStatus": "needs-survey"
    },
    {
      "id": "c6-17",
      "label": "Коридор",
      "floor": 6,
      "x": 1075,
      "y": 250,
      "kind": "corridor",
      "positionStatus": "needs-survey"
    },
    {
      "id": "c6-18",
      "label": "Коридор",
      "floor": 6,
      "x": 1130,
      "y": 250,
      "kind": "corridor",
      "positionStatus": "needs-survey"
    },
    {
      "id": "611а",
      "label": "Аудитория 611а",
      "floor": 6,
      "x": 140,
      "y": 170,
      "kind": "room",
      "existenceStatus": "official-list",
      "floorStatus": "inferred-from-number",
      "positionStatus": "needs-survey",
      "source": "cabs"
    },
    {
      "id": "612",
      "label": "Аудитория 612",
      "floor": 6,
      "x": 195,
      "y": 330,
      "kind": "room",
      "existenceStatus": "official-list",
      "floorStatus": "inferred-from-number",
      "positionStatus": "needs-survey",
      "source": "cabs"
    },
    {
      "id": "614",
      "label": "Аудитория 614",
      "floor": 6,
      "x": 250,
      "y": 170,
      "kind": "room",
      "existenceStatus": "official-list",
      "floorStatus": "inferred-from-number",
      "positionStatus": "needs-survey",
      "source": "cabs"
    },
    {
      "id": "616",
      "label": "Аудитория 616",
      "floor": 6,
      "x": 305,
      "y": 330,
      "kind": "room",
      "existenceStatus": "official-list",
      "floorStatus": "inferred-from-number",
      "positionStatus": "needs-survey",
      "source": "cabs"
    },
    {
      "id": "618",
      "label": "Аудитория 618",
      "floor": 6,
      "x": 360,
      "y": 170,
      "kind": "room",
      "existenceStatus": "official-list",
      "floorStatus": "inferred-from-number",
      "positionStatus": "needs-survey",
      "source": "cabs"
    },
    {
      "id": "620",
      "label": "Аудитория 620",
      "floor": 6,
      "x": 415,
      "y": 330,
      "kind": "room",
      "existenceStatus": "official-list",
      "floorStatus": "inferred-from-number",
      "positionStatus": "needs-survey",
      "source": "cabs"
    },
    {
      "id": "sA6",
      "label": "Лестница A",
      "floor": 6,
      "x": 140,
      "y": 250,
      "kind": "stairs",
      "positionStatus": "needs-survey"
    },
    {
      "id": "sB6",
      "label": "Лестница B",
      "floor": 6,
      "x": 1130,
      "y": 250,
      "kind": "stairs",
      "positionStatus": "needs-survey"
    },
    {
      "id": "c7-0",
      "label": "Коридор",
      "floor": 7,
      "x": 140,
      "y": 250,
      "kind": "corridor",
      "positionStatus": "needs-survey"
    },
    {
      "id": "c7-1",
      "label": "Коридор",
      "floor": 7,
      "x": 195,
      "y": 250,
      "kind": "corridor",
      "positionStatus": "needs-survey"
    },
    {
      "id": "c7-2",
      "label": "Коридор",
      "floor": 7,
      "x": 250,
      "y": 250,
      "kind": "corridor",
      "positionStatus": "needs-survey"
    },
    {
      "id": "c7-3",
      "label": "Коридор",
      "floor": 7,
      "x": 305,
      "y": 250,
      "kind": "corridor",
      "positionStatus": "needs-survey"
    },
    {
      "id": "c7-4",
      "label": "Коридор",
      "floor": 7,
      "x": 360,
      "y": 250,
      "kind": "corridor",
      "positionStatus": "needs-survey"
    },
    {
      "id": "c7-5",
      "label": "Коридор",
      "floor": 7,
      "x": 415,
      "y": 250,
      "kind": "corridor",
      "positionStatus": "needs-survey"
    },
    {
      "id": "c7-6",
      "label": "Коридор",
      "floor": 7,
      "x": 470,
      "y": 250,
      "kind": "corridor",
      "positionStatus": "needs-survey"
    },
    {
      "id": "c7-7",
      "label": "Коридор",
      "floor": 7,
      "x": 525,
      "y": 250,
      "kind": "corridor",
      "positionStatus": "needs-survey"
    },
    {
      "id": "c7-8",
      "label": "Коридор",
      "floor": 7,
      "x": 580,
      "y": 250,
      "kind": "corridor",
      "positionStatus": "needs-survey"
    },
    {
      "id": "c7-9",
      "label": "Коридор",
      "floor": 7,
      "x": 635,
      "y": 250,
      "kind": "corridor",
      "positionStatus": "needs-survey"
    },
    {
      "id": "c7-10",
      "label": "Коридор",
      "floor": 7,
      "x": 690,
      "y": 250,
      "kind": "corridor",
      "positionStatus": "needs-survey"
    },
    {
      "id": "c7-11",
      "label": "Коридор",
      "floor": 7,
      "x": 745,
      "y": 250,
      "kind": "corridor",
      "positionStatus": "needs-survey"
    },
    {
      "id": "c7-12",
      "label": "Коридор",
      "floor": 7,
      "x": 800,
      "y": 250,
      "kind": "corridor",
      "positionStatus": "needs-survey"
    },
    {
      "id": "c7-13",
      "label": "Коридор",
      "floor": 7,
      "x": 855,
      "y": 250,
      "kind": "corridor",
      "positionStatus": "needs-survey"
    },
    {
      "id": "c7-14",
      "label": "Коридор",
      "floor": 7,
      "x": 910,
      "y": 250,
      "kind": "corridor",
      "positionStatus": "needs-survey"
    },
    {
      "id": "c7-15",
      "label": "Коридор",
      "floor": 7,
      "x": 965,
      "y": 250,
      "kind": "corridor",
      "positionStatus": "needs-survey"
    },
    {
      "id": "c7-16",
      "label": "Коридор",
      "floor": 7,
      "x": 1020,
      "y": 250,
      "kind": "corridor",
      "positionStatus": "needs-survey"
    },
    {
      "id": "c7-17",
      "label": "Коридор",
      "floor": 7,
      "x": 1075,
      "y": 250,
      "kind": "corridor",
      "positionStatus": "needs-survey"
    },
    {
      "id": "c7-18",
      "label": "Коридор",
      "floor": 7,
      "x": 1130,
      "y": 250,
      "kind": "corridor",
      "positionStatus": "needs-survey"
    },
    {
      "id": "710",
      "label": "Аудитория 710",
      "floor": 7,
      "x": 140,
      "y": 170,
      "kind": "room",
      "existenceStatus": "official-list",
      "floorStatus": "inferred-from-number",
      "positionStatus": "needs-survey",
      "source": "cabs"
    },
    {
      "id": "712",
      "label": "Аудитория 712",
      "floor": 7,
      "x": 195,
      "y": 330,
      "kind": "room",
      "existenceStatus": "official-list",
      "floorStatus": "inferred-from-number",
      "positionStatus": "needs-survey",
      "source": "cabs"
    },
    {
      "id": "714",
      "label": "Аудитория 714",
      "floor": 7,
      "x": 250,
      "y": 170,
      "kind": "room",
      "existenceStatus": "official-list",
      "floorStatus": "inferred-from-number",
      "positionStatus": "needs-survey",
      "source": "cabs"
    },
    {
      "id": "716",
      "label": "Аудитория 716",
      "floor": 7,
      "x": 305,
      "y": 330,
      "kind": "room",
      "existenceStatus": "official-list",
      "floorStatus": "inferred-from-number",
      "positionStatus": "needs-survey",
      "source": "cabs"
    },
    {
      "id": "722",
      "label": "Аудитория 722",
      "floor": 7,
      "x": 360,
      "y": 170,
      "kind": "room",
      "existenceStatus": "official-list",
      "floorStatus": "inferred-from-number",
      "positionStatus": "needs-survey",
      "source": "cabs"
    },
    {
      "id": "726",
      "label": "Аудитория 726",
      "floor": 7,
      "x": 415,
      "y": 330,
      "kind": "room",
      "existenceStatus": "official-list",
      "floorStatus": "inferred-from-number",
      "positionStatus": "needs-survey",
      "source": "cabs"
    },
    {
      "id": "sA7",
      "label": "Лестница A",
      "floor": 7,
      "x": 140,
      "y": 250,
      "kind": "stairs",
      "positionStatus": "needs-survey"
    },
    {
      "id": "sB7",
      "label": "Лестница B",
      "floor": 7,
      "x": 1130,
      "y": 250,
      "kind": "stairs",
      "positionStatus": "needs-survey"
    },
    {
      "id": "c8-0",
      "label": "Коридор",
      "floor": 8,
      "x": 140,
      "y": 250,
      "kind": "corridor",
      "positionStatus": "needs-survey"
    },
    {
      "id": "c8-1",
      "label": "Коридор",
      "floor": 8,
      "x": 195,
      "y": 250,
      "kind": "corridor",
      "positionStatus": "needs-survey"
    },
    {
      "id": "c8-2",
      "label": "Коридор",
      "floor": 8,
      "x": 250,
      "y": 250,
      "kind": "corridor",
      "positionStatus": "needs-survey"
    },
    {
      "id": "c8-3",
      "label": "Коридор",
      "floor": 8,
      "x": 305,
      "y": 250,
      "kind": "corridor",
      "positionStatus": "needs-survey"
    },
    {
      "id": "c8-4",
      "label": "Коридор",
      "floor": 8,
      "x": 360,
      "y": 250,
      "kind": "corridor",
      "positionStatus": "needs-survey"
    },
    {
      "id": "c8-5",
      "label": "Коридор",
      "floor": 8,
      "x": 415,
      "y": 250,
      "kind": "corridor",
      "positionStatus": "needs-survey"
    },
    {
      "id": "c8-6",
      "label": "Коридор",
      "floor": 8,
      "x": 470,
      "y": 250,
      "kind": "corridor",
      "positionStatus": "needs-survey"
    },
    {
      "id": "c8-7",
      "label": "Коридор",
      "floor": 8,
      "x": 525,
      "y": 250,
      "kind": "corridor",
      "positionStatus": "needs-survey"
    },
    {
      "id": "c8-8",
      "label": "Коридор",
      "floor": 8,
      "x": 580,
      "y": 250,
      "kind": "corridor",
      "positionStatus": "needs-survey"
    },
    {
      "id": "c8-9",
      "label": "Коридор",
      "floor": 8,
      "x": 635,
      "y": 250,
      "kind": "corridor",
      "positionStatus": "needs-survey"
    },
    {
      "id": "c8-10",
      "label": "Коридор",
      "floor": 8,
      "x": 690,
      "y": 250,
      "kind": "corridor",
      "positionStatus": "needs-survey"
    },
    {
      "id": "c8-11",
      "label": "Коридор",
      "floor": 8,
      "x": 745,
      "y": 250,
      "kind": "corridor",
      "positionStatus": "needs-survey"
    },
    {
      "id": "c8-12",
      "label": "Коридор",
      "floor": 8,
      "x": 800,
      "y": 250,
      "kind": "corridor",
      "positionStatus": "needs-survey"
    },
    {
      "id": "c8-13",
      "label": "Коридор",
      "floor": 8,
      "x": 855,
      "y": 250,
      "kind": "corridor",
      "positionStatus": "needs-survey"
    },
    {
      "id": "c8-14",
      "label": "Коридор",
      "floor": 8,
      "x": 910,
      "y": 250,
      "kind": "corridor",
      "positionStatus": "needs-survey"
    },
    {
      "id": "c8-15",
      "label": "Коридор",
      "floor": 8,
      "x": 965,
      "y": 250,
      "kind": "corridor",
      "positionStatus": "needs-survey"
    },
    {
      "id": "c8-16",
      "label": "Коридор",
      "floor": 8,
      "x": 1020,
      "y": 250,
      "kind": "corridor",
      "positionStatus": "needs-survey"
    },
    {
      "id": "c8-17",
      "label": "Коридор",
      "floor": 8,
      "x": 1075,
      "y": 250,
      "kind": "corridor",
      "positionStatus": "needs-survey"
    },
    {
      "id": "c8-18",
      "label": "Коридор",
      "floor": 8,
      "x": 1130,
      "y": 250,
      "kind": "corridor",
      "positionStatus": "needs-survey"
    },
    {
      "id": "sA8",
      "label": "Лестница A",
      "floor": 8,
      "x": 140,
      "y": 250,
      "kind": "stairs",
      "positionStatus": "needs-survey"
    },
    {
      "id": "sB8",
      "label": "Лестница B",
      "floor": 8,
      "x": 1130,
      "y": 250,
      "kind": "stairs",
      "positionStatus": "needs-survey"
    },
    {
      "id": "entrance",
      "label": "Вход (условное положение)",
      "floor": 1,
      "x": 85,
      "y": 250,
      "kind": "entrance",
      "positionStatus": "needs-survey"
    }
  ],
  "edges": [
    {
      "a": "c1-0",
      "b": "c1-1",
      "weight": 10,
      "kind": "corridor",
      "status": "needs-survey"
    },
    {
      "a": "c1-1",
      "b": "c1-2",
      "weight": 10,
      "kind": "corridor",
      "status": "needs-survey"
    },
    {
      "a": "c1-2",
      "b": "c1-3",
      "weight": 10,
      "kind": "corridor",
      "status": "needs-survey"
    },
    {
      "a": "c1-3",
      "b": "c1-4",
      "weight": 10,
      "kind": "corridor",
      "status": "needs-survey"
    },
    {
      "a": "c1-4",
      "b": "c1-5",
      "weight": 10,
      "kind": "corridor",
      "status": "needs-survey"
    },
    {
      "a": "c1-5",
      "b": "c1-6",
      "weight": 10,
      "kind": "corridor",
      "status": "needs-survey"
    },
    {
      "a": "c1-6",
      "b": "c1-7",
      "weight": 10,
      "kind": "corridor",
      "status": "needs-survey"
    },
    {
      "a": "c1-7",
      "b": "c1-8",
      "weight": 10,
      "kind": "corridor",
      "status": "needs-survey"
    },
    {
      "a": "c1-8",
      "b": "c1-9",
      "weight": 10,
      "kind": "corridor",
      "status": "needs-survey"
    },
    {
      "a": "c1-9",
      "b": "c1-10",
      "weight": 10,
      "kind": "corridor",
      "status": "needs-survey"
    },
    {
      "a": "c1-10",
      "b": "c1-11",
      "weight": 10,
      "kind": "corridor",
      "status": "needs-survey"
    },
    {
      "a": "c1-11",
      "b": "c1-12",
      "weight": 10,
      "kind": "corridor",
      "status": "needs-survey"
    },
    {
      "a": "c1-12",
      "b": "c1-13",
      "weight": 10,
      "kind": "corridor",
      "status": "needs-survey"
    },
    {
      "a": "c1-13",
      "b": "c1-14",
      "weight": 10,
      "kind": "corridor",
      "status": "needs-survey"
    },
    {
      "a": "c1-14",
      "b": "c1-15",
      "weight": 10,
      "kind": "corridor",
      "status": "needs-survey"
    },
    {
      "a": "c1-15",
      "b": "c1-16",
      "weight": 10,
      "kind": "corridor",
      "status": "needs-survey"
    },
    {
      "a": "c1-16",
      "b": "c1-17",
      "weight": 10,
      "kind": "corridor",
      "status": "needs-survey"
    },
    {
      "a": "c1-17",
      "b": "c1-18",
      "weight": 10,
      "kind": "corridor",
      "status": "needs-survey"
    },
    {
      "a": "101",
      "b": "c1-0",
      "weight": 3,
      "kind": "corridor",
      "status": "needs-survey"
    },
    {
      "a": "113",
      "b": "c1-1",
      "weight": 3,
      "kind": "corridor",
      "status": "needs-survey"
    },
    {
      "a": "122",
      "b": "c1-2",
      "weight": 3,
      "kind": "corridor",
      "status": "needs-survey"
    },
    {
      "a": "124",
      "b": "c1-3",
      "weight": 3,
      "kind": "corridor",
      "status": "needs-survey"
    },
    {
      "a": "sA1",
      "b": "c1-0",
      "weight": 1,
      "kind": "corridor",
      "status": "needs-survey"
    },
    {
      "a": "sB1",
      "b": "c1-18",
      "weight": 1,
      "kind": "corridor",
      "status": "needs-survey"
    },
    {
      "a": "c2-0",
      "b": "c2-1",
      "weight": 10,
      "kind": "corridor",
      "status": "needs-survey"
    },
    {
      "a": "c2-1",
      "b": "c2-2",
      "weight": 10,
      "kind": "corridor",
      "status": "needs-survey"
    },
    {
      "a": "c2-2",
      "b": "c2-3",
      "weight": 10,
      "kind": "corridor",
      "status": "needs-survey"
    },
    {
      "a": "c2-3",
      "b": "c2-4",
      "weight": 10,
      "kind": "corridor",
      "status": "needs-survey"
    },
    {
      "a": "c2-4",
      "b": "c2-5",
      "weight": 10,
      "kind": "corridor",
      "status": "needs-survey"
    },
    {
      "a": "c2-5",
      "b": "c2-6",
      "weight": 10,
      "kind": "corridor",
      "status": "needs-survey"
    },
    {
      "a": "c2-6",
      "b": "c2-7",
      "weight": 10,
      "kind": "corridor",
      "status": "needs-survey"
    },
    {
      "a": "c2-7",
      "b": "c2-8",
      "weight": 10,
      "kind": "corridor",
      "status": "needs-survey"
    },
    {
      "a": "c2-8",
      "b": "c2-9",
      "weight": 10,
      "kind": "corridor",
      "status": "needs-survey"
    },
    {
      "a": "c2-9",
      "b": "c2-10",
      "weight": 10,
      "kind": "corridor",
      "status": "needs-survey"
    },
    {
      "a": "c2-10",
      "b": "c2-11",
      "weight": 10,
      "kind": "corridor",
      "status": "needs-survey"
    },
    {
      "a": "c2-11",
      "b": "c2-12",
      "weight": 10,
      "kind": "corridor",
      "status": "needs-survey"
    },
    {
      "a": "c2-12",
      "b": "c2-13",
      "weight": 10,
      "kind": "corridor",
      "status": "needs-survey"
    },
    {
      "a": "c2-13",
      "b": "c2-14",
      "weight": 10,
      "kind": "corridor",
      "status": "needs-survey"
    },
    {
      "a": "c2-14",
      "b": "c2-15",
      "weight": 10,
      "kind": "corridor",
      "status": "needs-survey"
    },
    {
      "a": "c2-15",
      "b": "c2-16",
      "weight": 10,
      "kind": "corridor",
      "status": "needs-survey"
    },
    {
      "a": "c2-16",
      "b": "c2-17",
      "weight": 10,
      "kind": "corridor",
      "status": "needs-survey"
    },
    {
      "a": "c2-17",
      "b": "c2-18",
      "weight": 10,
      "kind": "corridor",
      "status": "needs-survey"
    },
    {
      "a": "201",
      "b": "c2-0",
      "weight": 3,
      "kind": "corridor",
      "status": "needs-survey"
    },
    {
      "a": "202",
      "b": "c2-1",
      "weight": 3,
      "kind": "corridor",
      "status": "needs-survey"
    },
    {
      "a": "203",
      "b": "c2-2",
      "weight": 3,
      "kind": "corridor",
      "status": "needs-survey"
    },
    {
      "a": "204",
      "b": "c2-3",
      "weight": 3,
      "kind": "corridor",
      "status": "needs-survey"
    },
    {
      "a": "205",
      "b": "c2-4",
      "weight": 3,
      "kind": "corridor",
      "status": "needs-survey"
    },
    {
      "a": "206",
      "b": "c2-5",
      "weight": 3,
      "kind": "corridor",
      "status": "needs-survey"
    },
    {
      "a": "207а",
      "b": "c2-6",
      "weight": 3,
      "kind": "corridor",
      "status": "needs-survey"
    },
    {
      "a": "208",
      "b": "c2-7",
      "weight": 3,
      "kind": "corridor",
      "status": "needs-survey"
    },
    {
      "a": "210",
      "b": "c2-8",
      "weight": 3,
      "kind": "corridor",
      "status": "needs-survey"
    },
    {
      "a": "211",
      "b": "c2-9",
      "weight": 3,
      "kind": "corridor",
      "status": "needs-survey"
    },
    {
      "a": "212",
      "b": "c2-10",
      "weight": 3,
      "kind": "corridor",
      "status": "needs-survey"
    },
    {
      "a": "214",
      "b": "c2-11",
      "weight": 3,
      "kind": "corridor",
      "status": "needs-survey"
    },
    {
      "a": "216",
      "b": "c2-12",
      "weight": 3,
      "kind": "corridor",
      "status": "needs-survey"
    },
    {
      "a": "218",
      "b": "c2-13",
      "weight": 3,
      "kind": "corridor",
      "status": "needs-survey"
    },
    {
      "a": "220",
      "b": "c2-14",
      "weight": 3,
      "kind": "corridor",
      "status": "needs-survey"
    },
    {
      "a": "224",
      "b": "c2-15",
      "weight": 3,
      "kind": "corridor",
      "status": "needs-survey"
    },
    {
      "a": "226а",
      "b": "c2-16",
      "weight": 3,
      "kind": "corridor",
      "status": "needs-survey"
    },
    {
      "a": "226б",
      "b": "c2-17",
      "weight": 3,
      "kind": "corridor",
      "status": "needs-survey"
    },
    {
      "a": "226в",
      "b": "c2-18",
      "weight": 3,
      "kind": "corridor",
      "status": "needs-survey"
    },
    {
      "a": "sA2",
      "b": "c2-0",
      "weight": 1,
      "kind": "corridor",
      "status": "needs-survey"
    },
    {
      "a": "sA1",
      "b": "sA2",
      "weight": 18,
      "kind": "stairs",
      "status": "needs-survey"
    },
    {
      "a": "sB2",
      "b": "c2-18",
      "weight": 1,
      "kind": "corridor",
      "status": "needs-survey"
    },
    {
      "a": "sB1",
      "b": "sB2",
      "weight": 18,
      "kind": "stairs",
      "status": "needs-survey"
    },
    {
      "a": "c3-0",
      "b": "c3-1",
      "weight": 10,
      "kind": "corridor",
      "status": "needs-survey"
    },
    {
      "a": "c3-1",
      "b": "c3-2",
      "weight": 10,
      "kind": "corridor",
      "status": "needs-survey"
    },
    {
      "a": "c3-2",
      "b": "c3-3",
      "weight": 10,
      "kind": "corridor",
      "status": "needs-survey"
    },
    {
      "a": "c3-3",
      "b": "c3-4",
      "weight": 10,
      "kind": "corridor",
      "status": "needs-survey"
    },
    {
      "a": "c3-4",
      "b": "c3-5",
      "weight": 10,
      "kind": "corridor",
      "status": "needs-survey"
    },
    {
      "a": "c3-5",
      "b": "c3-6",
      "weight": 10,
      "kind": "corridor",
      "status": "needs-survey"
    },
    {
      "a": "c3-6",
      "b": "c3-7",
      "weight": 10,
      "kind": "corridor",
      "status": "needs-survey"
    },
    {
      "a": "c3-7",
      "b": "c3-8",
      "weight": 10,
      "kind": "corridor",
      "status": "needs-survey"
    },
    {
      "a": "c3-8",
      "b": "c3-9",
      "weight": 10,
      "kind": "corridor",
      "status": "needs-survey"
    },
    {
      "a": "c3-9",
      "b": "c3-10",
      "weight": 10,
      "kind": "corridor",
      "status": "needs-survey"
    },
    {
      "a": "c3-10",
      "b": "c3-11",
      "weight": 10,
      "kind": "corridor",
      "status": "needs-survey"
    },
    {
      "a": "c3-11",
      "b": "c3-12",
      "weight": 10,
      "kind": "corridor",
      "status": "needs-survey"
    },
    {
      "a": "c3-12",
      "b": "c3-13",
      "weight": 10,
      "kind": "corridor",
      "status": "needs-survey"
    },
    {
      "a": "c3-13",
      "b": "c3-14",
      "weight": 10,
      "kind": "corridor",
      "status": "needs-survey"
    },
    {
      "a": "c3-14",
      "b": "c3-15",
      "weight": 10,
      "kind": "corridor",
      "status": "needs-survey"
    },
    {
      "a": "c3-15",
      "b": "c3-16",
      "weight": 10,
      "kind": "corridor",
      "status": "needs-survey"
    },
    {
      "a": "c3-16",
      "b": "c3-17",
      "weight": 10,
      "kind": "corridor",
      "status": "needs-survey"
    },
    {
      "a": "c3-17",
      "b": "c3-18",
      "weight": 10,
      "kind": "corridor",
      "status": "needs-survey"
    },
    {
      "a": "315",
      "b": "c3-0",
      "weight": 3,
      "kind": "corridor",
      "status": "needs-survey"
    },
    {
      "a": "sA3",
      "b": "c3-0",
      "weight": 1,
      "kind": "corridor",
      "status": "needs-survey"
    },
    {
      "a": "sA2",
      "b": "sA3",
      "weight": 18,
      "kind": "stairs",
      "status": "needs-survey"
    },
    {
      "a": "sB3",
      "b": "c3-18",
      "weight": 1,
      "kind": "corridor",
      "status": "needs-survey"
    },
    {
      "a": "sB2",
      "b": "sB3",
      "weight": 18,
      "kind": "stairs",
      "status": "needs-survey"
    },
    {
      "a": "c4-0",
      "b": "c4-1",
      "weight": 10,
      "kind": "corridor",
      "status": "needs-survey"
    },
    {
      "a": "c4-1",
      "b": "c4-2",
      "weight": 10,
      "kind": "corridor",
      "status": "needs-survey"
    },
    {
      "a": "c4-2",
      "b": "c4-3",
      "weight": 10,
      "kind": "corridor",
      "status": "needs-survey"
    },
    {
      "a": "c4-3",
      "b": "c4-4",
      "weight": 10,
      "kind": "corridor",
      "status": "needs-survey"
    },
    {
      "a": "c4-4",
      "b": "c4-5",
      "weight": 10,
      "kind": "corridor",
      "status": "needs-survey"
    },
    {
      "a": "c4-5",
      "b": "c4-6",
      "weight": 10,
      "kind": "corridor",
      "status": "needs-survey"
    },
    {
      "a": "c4-6",
      "b": "c4-7",
      "weight": 10,
      "kind": "corridor",
      "status": "needs-survey"
    },
    {
      "a": "c4-7",
      "b": "c4-8",
      "weight": 10,
      "kind": "corridor",
      "status": "needs-survey"
    },
    {
      "a": "c4-8",
      "b": "c4-9",
      "weight": 10,
      "kind": "corridor",
      "status": "needs-survey"
    },
    {
      "a": "c4-9",
      "b": "c4-10",
      "weight": 10,
      "kind": "corridor",
      "status": "needs-survey"
    },
    {
      "a": "c4-10",
      "b": "c4-11",
      "weight": 10,
      "kind": "corridor",
      "status": "needs-survey"
    },
    {
      "a": "c4-11",
      "b": "c4-12",
      "weight": 10,
      "kind": "corridor",
      "status": "needs-survey"
    },
    {
      "a": "c4-12",
      "b": "c4-13",
      "weight": 10,
      "kind": "corridor",
      "status": "needs-survey"
    },
    {
      "a": "c4-13",
      "b": "c4-14",
      "weight": 10,
      "kind": "corridor",
      "status": "needs-survey"
    },
    {
      "a": "c4-14",
      "b": "c4-15",
      "weight": 10,
      "kind": "corridor",
      "status": "needs-survey"
    },
    {
      "a": "c4-15",
      "b": "c4-16",
      "weight": 10,
      "kind": "corridor",
      "status": "needs-survey"
    },
    {
      "a": "c4-16",
      "b": "c4-17",
      "weight": 10,
      "kind": "corridor",
      "status": "needs-survey"
    },
    {
      "a": "c4-17",
      "b": "c4-18",
      "weight": 10,
      "kind": "corridor",
      "status": "needs-survey"
    },
    {
      "a": "402",
      "b": "c4-0",
      "weight": 3,
      "kind": "corridor",
      "status": "needs-survey"
    },
    {
      "a": "404",
      "b": "c4-1",
      "weight": 3,
      "kind": "corridor",
      "status": "needs-survey"
    },
    {
      "a": "405",
      "b": "c4-2",
      "weight": 3,
      "kind": "corridor",
      "status": "needs-survey"
    },
    {
      "a": "406",
      "b": "c4-3",
      "weight": 3,
      "kind": "corridor",
      "status": "needs-survey"
    },
    {
      "a": "407",
      "b": "c4-4",
      "weight": 3,
      "kind": "corridor",
      "status": "needs-survey"
    },
    {
      "a": "407а",
      "b": "c4-5",
      "weight": 3,
      "kind": "corridor",
      "status": "needs-survey"
    },
    {
      "a": "412",
      "b": "c4-6",
      "weight": 3,
      "kind": "corridor",
      "status": "needs-survey"
    },
    {
      "a": "413а",
      "b": "c4-7",
      "weight": 3,
      "kind": "corridor",
      "status": "needs-survey"
    },
    {
      "a": "418",
      "b": "c4-8",
      "weight": 3,
      "kind": "corridor",
      "status": "needs-survey"
    },
    {
      "a": "sA4",
      "b": "c4-0",
      "weight": 1,
      "kind": "corridor",
      "status": "needs-survey"
    },
    {
      "a": "sA3",
      "b": "sA4",
      "weight": 18,
      "kind": "stairs",
      "status": "needs-survey"
    },
    {
      "a": "sB4",
      "b": "c4-18",
      "weight": 1,
      "kind": "corridor",
      "status": "needs-survey"
    },
    {
      "a": "sB3",
      "b": "sB4",
      "weight": 18,
      "kind": "stairs",
      "status": "needs-survey"
    },
    {
      "a": "c5-0",
      "b": "c5-1",
      "weight": 10,
      "kind": "corridor",
      "status": "needs-survey"
    },
    {
      "a": "c5-1",
      "b": "c5-2",
      "weight": 10,
      "kind": "corridor",
      "status": "needs-survey"
    },
    {
      "a": "c5-2",
      "b": "c5-3",
      "weight": 10,
      "kind": "corridor",
      "status": "needs-survey"
    },
    {
      "a": "c5-3",
      "b": "c5-4",
      "weight": 10,
      "kind": "corridor",
      "status": "needs-survey"
    },
    {
      "a": "c5-4",
      "b": "c5-5",
      "weight": 10,
      "kind": "corridor",
      "status": "needs-survey"
    },
    {
      "a": "c5-5",
      "b": "c5-6",
      "weight": 10,
      "kind": "corridor",
      "status": "needs-survey"
    },
    {
      "a": "c5-6",
      "b": "c5-7",
      "weight": 10,
      "kind": "corridor",
      "status": "needs-survey"
    },
    {
      "a": "c5-7",
      "b": "c5-8",
      "weight": 10,
      "kind": "corridor",
      "status": "needs-survey"
    },
    {
      "a": "c5-8",
      "b": "c5-9",
      "weight": 10,
      "kind": "corridor",
      "status": "needs-survey"
    },
    {
      "a": "c5-9",
      "b": "c5-10",
      "weight": 10,
      "kind": "corridor",
      "status": "needs-survey"
    },
    {
      "a": "c5-10",
      "b": "c5-11",
      "weight": 10,
      "kind": "corridor",
      "status": "needs-survey"
    },
    {
      "a": "c5-11",
      "b": "c5-12",
      "weight": 10,
      "kind": "corridor",
      "status": "needs-survey"
    },
    {
      "a": "c5-12",
      "b": "c5-13",
      "weight": 10,
      "kind": "corridor",
      "status": "needs-survey"
    },
    {
      "a": "c5-13",
      "b": "c5-14",
      "weight": 10,
      "kind": "corridor",
      "status": "needs-survey"
    },
    {
      "a": "c5-14",
      "b": "c5-15",
      "weight": 10,
      "kind": "corridor",
      "status": "needs-survey"
    },
    {
      "a": "c5-15",
      "b": "c5-16",
      "weight": 10,
      "kind": "corridor",
      "status": "needs-survey"
    },
    {
      "a": "c5-16",
      "b": "c5-17",
      "weight": 10,
      "kind": "corridor",
      "status": "needs-survey"
    },
    {
      "a": "c5-17",
      "b": "c5-18",
      "weight": 10,
      "kind": "corridor",
      "status": "needs-survey"
    },
    {
      "a": "503",
      "b": "c5-0",
      "weight": 3,
      "kind": "corridor",
      "status": "needs-survey"
    },
    {
      "a": "511",
      "b": "c5-1",
      "weight": 3,
      "kind": "corridor",
      "status": "needs-survey"
    },
    {
      "a": "513",
      "b": "c5-2",
      "weight": 3,
      "kind": "corridor",
      "status": "needs-survey"
    },
    {
      "a": "515",
      "b": "c5-3",
      "weight": 3,
      "kind": "corridor",
      "status": "needs-survey"
    },
    {
      "a": "sA5",
      "b": "c5-0",
      "weight": 1,
      "kind": "corridor",
      "status": "needs-survey"
    },
    {
      "a": "sA4",
      "b": "sA5",
      "weight": 18,
      "kind": "stairs",
      "status": "needs-survey"
    },
    {
      "a": "sB5",
      "b": "c5-18",
      "weight": 1,
      "kind": "corridor",
      "status": "needs-survey"
    },
    {
      "a": "sB4",
      "b": "sB5",
      "weight": 18,
      "kind": "stairs",
      "status": "needs-survey"
    },
    {
      "a": "c6-0",
      "b": "c6-1",
      "weight": 10,
      "kind": "corridor",
      "status": "needs-survey"
    },
    {
      "a": "c6-1",
      "b": "c6-2",
      "weight": 10,
      "kind": "corridor",
      "status": "needs-survey"
    },
    {
      "a": "c6-2",
      "b": "c6-3",
      "weight": 10,
      "kind": "corridor",
      "status": "needs-survey"
    },
    {
      "a": "c6-3",
      "b": "c6-4",
      "weight": 10,
      "kind": "corridor",
      "status": "needs-survey"
    },
    {
      "a": "c6-4",
      "b": "c6-5",
      "weight": 10,
      "kind": "corridor",
      "status": "needs-survey"
    },
    {
      "a": "c6-5",
      "b": "c6-6",
      "weight": 10,
      "kind": "corridor",
      "status": "needs-survey"
    },
    {
      "a": "c6-6",
      "b": "c6-7",
      "weight": 10,
      "kind": "corridor",
      "status": "needs-survey"
    },
    {
      "a": "c6-7",
      "b": "c6-8",
      "weight": 10,
      "kind": "corridor",
      "status": "needs-survey"
    },
    {
      "a": "c6-8",
      "b": "c6-9",
      "weight": 10,
      "kind": "corridor",
      "status": "needs-survey"
    },
    {
      "a": "c6-9",
      "b": "c6-10",
      "weight": 10,
      "kind": "corridor",
      "status": "needs-survey"
    },
    {
      "a": "c6-10",
      "b": "c6-11",
      "weight": 10,
      "kind": "corridor",
      "status": "needs-survey"
    },
    {
      "a": "c6-11",
      "b": "c6-12",
      "weight": 10,
      "kind": "corridor",
      "status": "needs-survey"
    },
    {
      "a": "c6-12",
      "b": "c6-13",
      "weight": 10,
      "kind": "corridor",
      "status": "needs-survey"
    },
    {
      "a": "c6-13",
      "b": "c6-14",
      "weight": 10,
      "kind": "corridor",
      "status": "needs-survey"
    },
    {
      "a": "c6-14",
      "b": "c6-15",
      "weight": 10,
      "kind": "corridor",
      "status": "needs-survey"
    },
    {
      "a": "c6-15",
      "b": "c6-16",
      "weight": 10,
      "kind": "corridor",
      "status": "needs-survey"
    },
    {
      "a": "c6-16",
      "b": "c6-17",
      "weight": 10,
      "kind": "corridor",
      "status": "needs-survey"
    },
    {
      "a": "c6-17",
      "b": "c6-18",
      "weight": 10,
      "kind": "corridor",
      "status": "needs-survey"
    },
    {
      "a": "611а",
      "b": "c6-0",
      "weight": 3,
      "kind": "corridor",
      "status": "needs-survey"
    },
    {
      "a": "612",
      "b": "c6-1",
      "weight": 3,
      "kind": "corridor",
      "status": "needs-survey"
    },
    {
      "a": "614",
      "b": "c6-2",
      "weight": 3,
      "kind": "corridor",
      "status": "needs-survey"
    },
    {
      "a": "616",
      "b": "c6-3",
      "weight": 3,
      "kind": "corridor",
      "status": "needs-survey"
    },
    {
      "a": "618",
      "b": "c6-4",
      "weight": 3,
      "kind": "corridor",
      "status": "needs-survey"
    },
    {
      "a": "620",
      "b": "c6-5",
      "weight": 3,
      "kind": "corridor",
      "status": "needs-survey"
    },
    {
      "a": "sA6",
      "b": "c6-0",
      "weight": 1,
      "kind": "corridor",
      "status": "needs-survey"
    },
    {
      "a": "sA5",
      "b": "sA6",
      "weight": 18,
      "kind": "stairs",
      "status": "needs-survey"
    },
    {
      "a": "sB6",
      "b": "c6-18",
      "weight": 1,
      "kind": "corridor",
      "status": "needs-survey"
    },
    {
      "a": "sB5",
      "b": "sB6",
      "weight": 18,
      "kind": "stairs",
      "status": "needs-survey"
    },
    {
      "a": "c7-0",
      "b": "c7-1",
      "weight": 10,
      "kind": "corridor",
      "status": "needs-survey"
    },
    {
      "a": "c7-1",
      "b": "c7-2",
      "weight": 10,
      "kind": "corridor",
      "status": "needs-survey"
    },
    {
      "a": "c7-2",
      "b": "c7-3",
      "weight": 10,
      "kind": "corridor",
      "status": "needs-survey"
    },
    {
      "a": "c7-3",
      "b": "c7-4",
      "weight": 10,
      "kind": "corridor",
      "status": "needs-survey"
    },
    {
      "a": "c7-4",
      "b": "c7-5",
      "weight": 10,
      "kind": "corridor",
      "status": "needs-survey"
    },
    {
      "a": "c7-5",
      "b": "c7-6",
      "weight": 10,
      "kind": "corridor",
      "status": "needs-survey"
    },
    {
      "a": "c7-6",
      "b": "c7-7",
      "weight": 10,
      "kind": "corridor",
      "status": "needs-survey"
    },
    {
      "a": "c7-7",
      "b": "c7-8",
      "weight": 10,
      "kind": "corridor",
      "status": "needs-survey"
    },
    {
      "a": "c7-8",
      "b": "c7-9",
      "weight": 10,
      "kind": "corridor",
      "status": "needs-survey"
    },
    {
      "a": "c7-9",
      "b": "c7-10",
      "weight": 10,
      "kind": "corridor",
      "status": "needs-survey"
    },
    {
      "a": "c7-10",
      "b": "c7-11",
      "weight": 10,
      "kind": "corridor",
      "status": "needs-survey"
    },
    {
      "a": "c7-11",
      "b": "c7-12",
      "weight": 10,
      "kind": "corridor",
      "status": "needs-survey"
    },
    {
      "a": "c7-12",
      "b": "c7-13",
      "weight": 10,
      "kind": "corridor",
      "status": "needs-survey"
    },
    {
      "a": "c7-13",
      "b": "c7-14",
      "weight": 10,
      "kind": "corridor",
      "status": "needs-survey"
    },
    {
      "a": "c7-14",
      "b": "c7-15",
      "weight": 10,
      "kind": "corridor",
      "status": "needs-survey"
    },
    {
      "a": "c7-15",
      "b": "c7-16",
      "weight": 10,
      "kind": "corridor",
      "status": "needs-survey"
    },
    {
      "a": "c7-16",
      "b": "c7-17",
      "weight": 10,
      "kind": "corridor",
      "status": "needs-survey"
    },
    {
      "a": "c7-17",
      "b": "c7-18",
      "weight": 10,
      "kind": "corridor",
      "status": "needs-survey"
    },
    {
      "a": "710",
      "b": "c7-0",
      "weight": 3,
      "kind": "corridor",
      "status": "needs-survey"
    },
    {
      "a": "712",
      "b": "c7-1",
      "weight": 3,
      "kind": "corridor",
      "status": "needs-survey"
    },
    {
      "a": "714",
      "b": "c7-2",
      "weight": 3,
      "kind": "corridor",
      "status": "needs-survey"
    },
    {
      "a": "716",
      "b": "c7-3",
      "weight": 3,
      "kind": "corridor",
      "status": "needs-survey"
    },
    {
      "a": "722",
      "b": "c7-4",
      "weight": 3,
      "kind": "corridor",
      "status": "needs-survey"
    },
    {
      "a": "726",
      "b": "c7-5",
      "weight": 3,
      "kind": "corridor",
      "status": "needs-survey"
    },
    {
      "a": "sA7",
      "b": "c7-0",
      "weight": 1,
      "kind": "corridor",
      "status": "needs-survey"
    },
    {
      "a": "sA6",
      "b": "sA7",
      "weight": 18,
      "kind": "stairs",
      "status": "needs-survey"
    },
    {
      "a": "sB7",
      "b": "c7-18",
      "weight": 1,
      "kind": "corridor",
      "status": "needs-survey"
    },
    {
      "a": "sB6",
      "b": "sB7",
      "weight": 18,
      "kind": "stairs",
      "status": "needs-survey"
    },
    {
      "a": "c8-0",
      "b": "c8-1",
      "weight": 10,
      "kind": "corridor",
      "status": "needs-survey"
    },
    {
      "a": "c8-1",
      "b": "c8-2",
      "weight": 10,
      "kind": "corridor",
      "status": "needs-survey"
    },
    {
      "a": "c8-2",
      "b": "c8-3",
      "weight": 10,
      "kind": "corridor",
      "status": "needs-survey"
    },
    {
      "a": "c8-3",
      "b": "c8-4",
      "weight": 10,
      "kind": "corridor",
      "status": "needs-survey"
    },
    {
      "a": "c8-4",
      "b": "c8-5",
      "weight": 10,
      "kind": "corridor",
      "status": "needs-survey"
    },
    {
      "a": "c8-5",
      "b": "c8-6",
      "weight": 10,
      "kind": "corridor",
      "status": "needs-survey"
    },
    {
      "a": "c8-6",
      "b": "c8-7",
      "weight": 10,
      "kind": "corridor",
      "status": "needs-survey"
    },
    {
      "a": "c8-7",
      "b": "c8-8",
      "weight": 10,
      "kind": "corridor",
      "status": "needs-survey"
    },
    {
      "a": "c8-8",
      "b": "c8-9",
      "weight": 10,
      "kind": "corridor",
      "status": "needs-survey"
    },
    {
      "a": "c8-9",
      "b": "c8-10",
      "weight": 10,
      "kind": "corridor",
      "status": "needs-survey"
    },
    {
      "a": "c8-10",
      "b": "c8-11",
      "weight": 10,
      "kind": "corridor",
      "status": "needs-survey"
    },
    {
      "a": "c8-11",
      "b": "c8-12",
      "weight": 10,
      "kind": "corridor",
      "status": "needs-survey"
    },
    {
      "a": "c8-12",
      "b": "c8-13",
      "weight": 10,
      "kind": "corridor",
      "status": "needs-survey"
    },
    {
      "a": "c8-13",
      "b": "c8-14",
      "weight": 10,
      "kind": "corridor",
      "status": "needs-survey"
    },
    {
      "a": "c8-14",
      "b": "c8-15",
      "weight": 10,
      "kind": "corridor",
      "status": "needs-survey"
    },
    {
      "a": "c8-15",
      "b": "c8-16",
      "weight": 10,
      "kind": "corridor",
      "status": "needs-survey"
    },
    {
      "a": "c8-16",
      "b": "c8-17",
      "weight": 10,
      "kind": "corridor",
      "status": "needs-survey"
    },
    {
      "a": "c8-17",
      "b": "c8-18",
      "weight": 10,
      "kind": "corridor",
      "status": "needs-survey"
    },
    {
      "a": "sA8",
      "b": "c8-0",
      "weight": 1,
      "kind": "corridor",
      "status": "needs-survey"
    },
    {
      "a": "sA7",
      "b": "sA8",
      "weight": 18,
      "kind": "stairs",
      "status": "needs-survey"
    },
    {
      "a": "sB8",
      "b": "c8-18",
      "weight": 1,
      "kind": "corridor",
      "status": "needs-survey"
    },
    {
      "a": "sB7",
      "b": "sB8",
      "weight": 18,
      "kind": "stairs",
      "status": "needs-survey"
    },
    {
      "a": "entrance",
      "b": "c1-0",
      "weight": 6,
      "kind": "corridor",
      "status": "needs-survey"
    }
  ],
  "pendingRooms": [
    {
      "id": "001",
      "reason": "Этаж и положение не установлены",
      "source": "cabs"
    }
  ],
  "sources": [
    {
      "id": "cabs",
      "url": "https://tulsu.ru/sveden/objects/cabs",
      "supports": "Существование перечисленных номеров аудиторий; не координаты"
    },
    {
      "id": "building",
      "url": "https://tulsu.ru/facilities/academic-building/8",
      "supports": "Корпус №9 и адрес"
    },
    {
      "id": "2gis",
      "url": "https://2gis.ru/tula/firm/70000001079767957",
      "supports": "Адрес и 8 этажей; поэтажные схемы не получены"
    }
  ]
};
